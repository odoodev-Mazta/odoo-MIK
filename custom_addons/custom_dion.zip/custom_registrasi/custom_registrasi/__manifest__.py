# -*- coding: utf-8 -*-
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).
{
    'name': 'Custom Registrasi BPOM & Halal',
    'version': '19.0.1.0.0',
    'category': 'Regulatory / Compliance',
    'summary': 'BPOM Brand (HAKI) and Product NIE Registration Workflow',
    'description': """
        Comprehensive compliance and workflow management module for BPOM
        (Indonesian FDA) and Halal registration. Integrates with custom_mou
        and custom_design modules.

        Features:
        - Brand/HAKI Registration workflow (registrasi.brand)
        - Product NIE Registration workflow (registrasi.produk)
        - Multi-tier approval system
        - SLA tracking for submissions
        - Finance payment workflow
        - BPOM review loop with confirmation counter
        - Automatic NIE linkage to product.template
    """,
    'author': 'MIK Regulatory Team',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'mail',
        'product',
        'custom_mou',
    ],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/sequence_data.xml',
        'views/registrasi_brand_views.xml',
        'views/registrasi_produk_views.xml',
        'views/registrasi_produk_line_views.xml',
        'views/registrasi_halal_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
