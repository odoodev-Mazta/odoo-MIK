from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import timedelta, date


class RegistrasiProduk(models.Model):
    _name = 'registrasi.produk'
    _description = 'Product NIE Registration to BPOM'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name desc'
    _rec_name = 'name'

    # ─── Sequence / Identity ────────────────────────────────────────────────
    name = fields.Char(
        string='Registration Number',
        copy=False,
        readonly=True,
        default=lambda self: _('New'),
        tracking=True,
    )
    product_name = fields.Char(
        string='Product Name (Request)',
        required=True,
        tracking=True,
    )
    official_product_name = fields.Char(
        string='Official Product Name (RO Drafted)',
        tracking=True,
        copy=False,
    )
    product_name_revision_count = fields.Integer(
        string='Product Name Revision Count',
        default=0,
        copy=False,
        tracking=True,
    )

    # ─── Brand Link ─────────────────────────────────────────────────────────
    brand_registration_id = fields.Many2one(
        comodel_name='registrasi.brand',
        string='Brand Registration',
        required=True,
        domain=[('state', '=', 'approved')],
        tracking=True,
        index=True,
    )
    client_id = fields.Many2one(
        comodel_name='res.partner',
        string='Client',
        related='brand_registration_id.client_id',
        store=True,
        readonly=True,
    )

    # ─── Category ───────────────────────────────────────────────────────────
    category = fields.Selection(
        selection=[
            ('import', 'Import'),
            ('lokal', 'Lokal'),
        ],
        string='Category',
        required=True,
        tracking=True,
    )

    # ─── Confirmation Counter ───────────────────────────────────────────────
    confirmation_counter = fields.Integer(
        string='BPOM Confirmation Counter',
        default=0,
        copy=False,
        tracking=True,
    )

    # ─── State ──────────────────────────────────────────────────────────────
    state = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('form_request', 'Form Request (Approval)'),
            ('ro_drafting', 'RO Drafting'),
            ('submitted', 'Submitted to BPOM'),
            ('payment_request', 'Payment Request'),
            ('payment_verification', 'Payment Verification'),
            ('bpom_review', 'BPOM Review'),
            ('nie_issued', 'NIE Issued'),
            ('failed', 'Failed'),
        ],
        string='Status',
        default='draft',
        required=True,
        copy=False,
        tracking=True,
        index=True,
    )

    # ─── Module Integration: custom_mou ─────────────────────────────────────
    mou_id = fields.Many2one(
        comodel_name='mou.mou',
        string='MoU Reference',
        tracking=True,
        domain=[('state', '=', 'active')],
        help='Required for Import category. Must contain the product in its line items.',
    )

    # ─── Module Integration: custom_design ──────────────────────────────────
    design_id = fields.Many2one(
        comodel_name='design.design',
        string='Design Reference',
        tracking=True,
        domain=[('state', '=', 'available')],
        help='Design artwork. Must be in "available" status before submitting to BPOM.',
    )
    design_sla_type = fields.Selection(
        selection=[
            ('standard', 'Standard (7 Days)'),
            ('custom', 'Custom (Manual)'),
        ],
        string='Design SLA Type',
        default='standard',
    )
    design_sla_days = fields.Integer(
        string='Design SLA (Days)',
        compute='_compute_design_sla_days',
        store=True,
    )

    # ─── Local Category: RnD & QC Integration ───────────────────────────────
    rnd_formula_ref = fields.Char(
        string='RnD Formula Reference',
        tracking=True,
    )
    raw_material_status = fields.Selection(
        selection=[
            ('incomplete', 'Incomplete'),
            ('complete', 'Complete'),
        ],
        string='Raw Material Status',
        default='incomplete',
        tracking=True,
    )
    qc_check_status = fields.Selection(
        selection=[
            ('pending', 'Pending'),
            ('passed', 'Passed'),
            ('failed', 'Failed'),
        ],
        string='QC Check Status',
        default='pending',
        tracking=True,
    )
    purchasing_import_status = fields.Selection(
        selection=[
            ('waiting', 'Waiting'),
            ('received', 'Received'),
        ],
        string='Packaging Material Status',
        default='waiting',
        tracking=True,
    )
    moq_qty = fields.Float(
        string='Minimum Order Quantity (MOQ)',
        digits=(16, 3),
    )

    # ─── Halal Specification ────────────────────────────────────────────────
    halal_type = fields.Selection(
        selection=[
            ('lokal', 'Lokal'),
            ('import', 'Import'),
        ],
        string='Halal Type',
        tracking=True,
    )
    halal_cert_attachment = fields.Binary(
        string='Halal Certificate',
        attachment=True,
    )
    halal_cert_fname = fields.Char(
        string='Halal Certificate Filename',
    )

    # ─── PNBP & Payment Documents ───────────────────────────────────────────
    doc_pnbp = fields.Binary(
        string='PNBP Document (Penerimaan Negara Bukan Pajak)',
        attachment=True,
        copy=False,
    )
    doc_pnbp_fname = fields.Char(
        string='PNBP Document Filename',
    )
    pnbp_notes = fields.Text(
        string='PNBP / Billing Notes',
    )

    # ─── BPOM Review Documents ──────────────────────────────────────────────
    doc_bpom_revision = fields.Binary(
        string='Revised Documents (BPOM Request)',
        attachment=True,
        copy=False,
    )
    doc_bpom_revision_fname = fields.Char(
        string='Revised Documents Filename',
    )
    bpom_review_notes = fields.Text(
        string='BPOM Review / Revision Notes',
        tracking=True,
    )
    bpom_review_deadline = fields.Date(
        string='BPOM Review Deadline (14 HK)',
        readonly=True,
        copy=False,
        tracking=True,
    )

    # ─── NIE Output ─────────────────────────────────────────────────────────
    nie_number = fields.Char(
        string='NIE Number',
        copy=False,
        tracking=True,
    )
    nie_issued_date = fields.Date(
        string='NIE Issued Date',
        copy=False,
        tracking=True,
    )
    nie_expired_date = fields.Date(
        string='NIE Expired Date',
        copy=False,
        tracking=True,
    )
    product_template_id = fields.Many2one(
        comodel_name='product.template',
        string='Linked Product (Odoo Master)',
        copy=False,
        readonly=True,
        tracking=True,
    )

    # ─── Multi-Approval Fields ──────────────────────────────────────────────
    approved_by_marketing = fields.Many2one(
        comodel_name='res.users',
        string='Approved by Product Marketing',
        readonly=True,
        copy=False,
        tracking=True,
    )
    approved_date_marketing = fields.Datetime(
        string='Marketing Approval Date',
        readonly=True,
        copy=False,
    )
    approved_by_regulatory = fields.Many2one(
        comodel_name='res.users',
        string='Approved by Regulatory',
        readonly=True,
        copy=False,
        tracking=True,
    )
    approved_date_regulatory = fields.Datetime(
        string='Regulatory Approval Date',
        readonly=True,
        copy=False,
    )
    approved_by_factory = fields.Many2one(
        comodel_name='res.users',
        string='Approved by Factory Manager',
        readonly=True,
        copy=False,
        tracking=True,
    )
    approved_date_factory = fields.Datetime(
        string='Factory Approval Date',
        readonly=True,
        copy=False,
    )
    approval_state = fields.Selection(
        selection=[
            ('waiting_marketing', 'Waiting Marketing Approval'),
            ('waiting_regulatory', 'Waiting Regulatory Approval'),
            ('waiting_factory', 'Waiting Factory Manager Approval'),
            ('all_approved', 'All Approved'),
        ],
        string='Approval Progress',
        compute='_compute_approval_state',
        store=True,
    )

    # ─── Product Lines ──────────────────────────────────────────────────────
    product_line_ids = fields.One2many(
        comodel_name='registrasi.produk.line',
        inverse_name='produk_id',
        string='Product Lines',
    )

    # ─── Deadlines ──────────────────────────────────────────────────────────
    submit_deadline = fields.Date(
        string='Submit Deadline',
        copy=False,
        tracking=True,
    )

    # ────────────────────────────────────────────────────────────────────────
    # Computes
    # ────────────────────────────────────────────────────────────────────────

    @api.depends('design_sla_type')
    def _compute_design_sla_days(self):
        for rec in self:
            if rec.design_sla_type == 'standard':
                rec.design_sla_days = 7
            else:
                rec.design_sla_days = 0  # Manual / custom

    @api.depends(
        'approved_by_marketing',
        'approved_by_regulatory',
        'approved_by_factory',
    )
    def _compute_approval_state(self):
        for rec in self:
            if not rec.approved_by_marketing:
                rec.approval_state = 'waiting_marketing'
            elif not rec.approved_by_regulatory:
                rec.approval_state = 'waiting_regulatory'
            elif not rec.approved_by_factory:
                rec.approval_state = 'waiting_factory'
            else:
                rec.approval_state = 'all_approved'

    # ────────────────────────────────────────────────────────────────────────
    # Onchange
    # ────────────────────────────────────────────────────────────────────────

    @api.onchange('category')
    def _onchange_category(self):
        """Clear MoU when category changes away from import."""
        if self.category != 'import':
            self.mou_id = False

    @api.onchange('mou_id')
    def _onchange_mou_id(self):
        """Warn if selected MoU does not contain this product."""
        pass  # Validation done in Python constraint

    # ────────────────────────────────────────────────────────────────────────
    # Constraints
    # ────────────────────────────────────────────────────────────────────────

    @api.constrains('category', 'mou_id')
    def _check_mou_required_for_import(self):
        for rec in self:
            if rec.category == 'import' and not rec.mou_id:
                raise ValidationError(
                    _('An MoU Reference is mandatory for Import category products.')
                )

    @api.constrains('confirmation_counter')
    def _check_confirmation_counter_limit(self):
        for rec in self:
            if rec.confirmation_counter > 3 and rec.state not in ('failed', 'nie_issued'):
                raise ValidationError(
                    _('BPOM Confirmation Counter exceeded the maximum of 3. '
                      'The registration has been automatically marked as Failed.')
                )

    # ────────────────────────────────────────────────────────────────────────
    # ORM Overrides
    # ────────────────────────────────────────────────────────────────────────

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'registrasi.produk'
                ) or _('New')
        return super().create(vals_list)

    def copy(self, default=None):
        default = dict(default or {})
        default['name'] = _('New')
        default['state'] = 'draft'
        default['confirmation_counter'] = 0
        default['approved_by_marketing'] = False
        default['approved_by_regulatory'] = False
        default['approved_by_factory'] = False
        return super().copy(default)

    def write(self, vals):
        """Auto-fail when confirmation counter exceeds 3."""
        res = super().write(vals)
        for rec in self:
            if (
                rec.confirmation_counter > 3
                and rec.state not in ('failed', 'nie_issued')
            ):
                rec._action_auto_fail()
        return res

    # ────────────────────────────────────────────────────────────────────────
    # Internal Helpers
    # ────────────────────────────────────────────────────────────────────────

    def _check_all_approved(self):
        """Return True if all 3 approvals are complete."""
        self.ensure_one()
        return bool(
            self.approved_by_marketing
            and self.approved_by_regulatory
            and self.approved_by_factory
        )

    def _action_auto_fail(self):
        """Automatically set state to failed when counter exceeds limit."""
        self.ensure_one()
        self.state = 'failed'
        self.message_post(
            body=_(
                'Registration automatically FAILED: BPOM confirmation counter '
                'exceeded the maximum of 3 revisions.'
            ),
            message_type='notification',
            subtype_xmlid='mail.mt_comment',
        )

    def _get_current_user_approval_role(self):
        """Detect which approval role the current user belongs to."""
        user = self.env.user
        marketing_group = self.env.ref(
            'custom_registrasi.group_registrasi_product_marketing',
            raise_if_not_found=False,
        )
        regulatory_group = self.env.ref(
            'custom_registrasi.group_registrasi_regulatory',
            raise_if_not_found=False,
        )
        factory_group = self.env.ref(
            'custom_registrasi.group_registrasi_factory_manager',
            raise_if_not_found=False,
        )
        if marketing_group and user in marketing_group.users:
            return 'marketing'
        if regulatory_group and user in regulatory_group.users:
            return 'regulatory'
        if factory_group and user in factory_group.users:
            return 'factory'
        return None

    # ────────────────────────────────────────────────────────────────────────
    # State Transition Actions
    # ────────────────────────────────────────────────────────────────────────

    def action_submit_form_request(self):
        """Draft → Form Request (Approval)."""
        for rec in self:
            if rec.category == 'import' and not rec.mou_id:
                raise UserError(
                    _('An MoU Reference is required for Import category before requesting approval.')
                )
            if not rec.product_line_ids:
                raise UserError(
                    _('Please add at least one product line before submitting.')
                )
            rec.write({'state': 'form_request'})
            rec.message_post(
                body=_('Form Request submitted. Awaiting 3-tier approval.'),
                message_type='notification',
            )
        return True

    # ── 3-Tier Approval ─────────────────────────────────────────────────────

    def action_approve_marketing(self):
        """Tier 1: Product Marketing approval."""
        for rec in self:
            if rec.state != 'form_request':
                raise UserError(_('Record must be in Form Request state to approve.'))
            if rec.approved_by_marketing:
                raise UserError(_('Marketing approval has already been given.'))
            rec.write({
                'approved_by_marketing': self.env.uid,
                'approved_date_marketing': fields.Datetime.now(),
            })
            rec.message_post(
                body=_('✅ Tier 1 – Product Marketing approved by %s.')
                % self.env.user.name,
                message_type='notification',
            )
            # Auto-progress if all approvals done
            if rec._check_all_approved():
                rec._action_move_to_ro_drafting()
        return True

    def action_approve_regulatory(self):
        """Tier 2: Regulatory approval."""
        for rec in self:
            if rec.state != 'form_request':
                raise UserError(_('Record must be in Form Request state to approve.'))
            if not rec.approved_by_marketing:
                raise UserError(
                    _('Marketing approval (Tier 1) must be completed first.')
                )
            if rec.approved_by_regulatory:
                raise UserError(_('Regulatory approval has already been given.'))
            rec.write({
                'approved_by_regulatory': self.env.uid,
                'approved_date_regulatory': fields.Datetime.now(),
            })
            rec.message_post(
                body=_('✅ Tier 2 – Regulatory approved by %s.') % self.env.user.name,
                message_type='notification',
            )
            if rec._check_all_approved():
                rec._action_move_to_ro_drafting()
        return True

    def action_approve_factory(self):
        """Tier 3: Factory Manager approval."""
        for rec in self:
            if rec.state != 'form_request':
                raise UserError(_('Record must be in Form Request state to approve.'))
            if not rec.approved_by_regulatory:
                raise UserError(
                    _('Regulatory approval (Tier 2) must be completed first.')
                )
            if rec.approved_by_factory:
                raise UserError(_('Factory Manager approval has already been given.'))
            rec.write({
                'approved_by_factory': self.env.uid,
                'approved_date_factory': fields.Datetime.now(),
            })
            rec.message_post(
                body=_('✅ Tier 3 – Factory Manager approved by %s.') % self.env.user.name,
                message_type='notification',
            )
            if rec._check_all_approved():
                rec._action_move_to_ro_drafting()
        return True

    def _action_move_to_ro_drafting(self):
        """Internal: move to RO Drafting after all approvals."""
        self.ensure_one()
        self.write({'state': 'ro_drafting'})
        self.message_post(
            body=_('All 3 approval tiers completed. Record moved to RO Drafting.'),
            message_type='notification',
            subtype_xmlid='mail.mt_comment',
        )

    # ── RO Drafting → Submitted ──────────────────────────────────────────────

    def action_confirm_official_name_and_submit(self):
        """RO Drafting → Submitted. Validates design availability."""
        for rec in self:
            if not rec.official_product_name:
                raise UserError(
                    _('Please draft and set the Official Product Name before submitting.')
                )
            if not rec.design_id:
                raise UserError(
                    _('A Design Reference must be selected before submitting to BPOM.')
                )
            if rec.design_id.state != 'available':
                raise UserError(
                    _('The linked Design must be in "Available" status. '
                      'Current status: %s') % rec.design_id.state
                )
            today = fields.Date.today()
            rec.write({
                'state': 'submitted',
                'submit_deadline': today + timedelta(days=7),
            })
            rec.message_post(
                body=_(
                    'Product submitted to BPOM. Official name: "%s". '
                    'PNBP document upload expected.'
                ) % rec.official_product_name,
                message_type='notification',
            )
        return True

    # ── Submitted → Payment Request ──────────────────────────────────────────

    def action_request_payment(self):
        """Submitted → Payment Request. PNBP document required."""
        for rec in self:
            if not rec.doc_pnbp:
                raise UserError(
                    _('Please upload the PNBP (Penerimaan Negara Bukan Pajak) '
                      'document before requesting payment.')
                )
            rec.write({'state': 'payment_request'})
            rec.message_post(
                body=_('Payment request sent to Finance with attached PNBP document.'),
                message_type='notification',
            )
        return True

    # ── Payment Request → Payment Verification ────────────────────────────────

    def action_finance_approve_payment(self):
        """Finance: Payment Request → Payment Verification → BPOM Review."""
        for rec in self:
            rec.write({
                'state': 'bpom_review',
                'bpom_review_deadline': fields.Date.today() + timedelta(days=14),
            })
            rec.message_post(
                body=_(
                    'Payment verified by Finance (%s). Record automatically moved '
                    'to BPOM Review. Review deadline: %s'
                ) % (
                    self.env.user.name,
                    (fields.Date.today() + timedelta(days=14)).strftime('%d %B %Y'),
                ),
                message_type='notification',
                subtype_xmlid='mail.mt_comment',
            )
        return True

    # ── BPOM Review ──────────────────────────────────────────────────────────

    def action_resubmit_to_bpom(self):
        """Re-submit revised documents to BPOM (from bpom_review state).
        Increments confirmation_counter. Auto-fails at >3."""
        for rec in self:
            if not rec.doc_bpom_revision:
                raise UserError(
                    _('Please upload the revised documents before re-submitting to BPOM.')
                )
            new_counter = rec.confirmation_counter + 1
            if new_counter > 3:
                rec.write({'state': 'failed', 'confirmation_counter': new_counter})
                rec.message_post(
                    body=_(
                        '❌ Registration FAILED: Maximum BPOM revision limit (3) exceeded.'
                    ),
                    message_type='notification',
                    subtype_xmlid='mail.mt_comment',
                )
            else:
                rec.write({
                    'confirmation_counter': new_counter,
                    'bpom_review_deadline': fields.Date.today() + timedelta(days=14),
                    'doc_bpom_revision': False,
                })
                rec.message_post(
                    body=_(
                        'Revised documents re-submitted to BPOM (revision #%d). '
                        'New review deadline: %s'
                    ) % (
                        new_counter,
                        (fields.Date.today() + timedelta(days=14)).strftime('%d %B %Y'),
                    ),
                    message_type='notification',
                )
        return True

    def action_revise_product_name(self):
        """RO requests product name revision during BPOM Review.
        Max 2 name revisions."""
        for rec in self:
            if rec.product_name_revision_count >= 2:
                raise UserError(
                    _('Product name can only be revised a maximum of 2 times '
                      'based on BPOM verifier feedback.')
                )
            rec.write({
                'product_name_revision_count': rec.product_name_revision_count + 1,
                'official_product_name': False,
                'state': 'ro_drafting',
            })
            rec.message_post(
                body=_(
                    'Product name revision #%d initiated. '
                    'RO must re-draft the official product name.'
                ) % rec.product_name_revision_count,
                message_type='notification',
                subtype_xmlid='mail.mt_comment',
            )
        return True

    def action_issue_nie(self):
        """BPOM Review → NIE Issued. Creates / links product.template."""
        for rec in self:
            if not rec.nie_number:
                raise UserError(
                    _('Please enter the NIE Number before marking as NIE Issued.')
                )
            if not rec.nie_issued_date:
                raise UserError(
                    _('Please enter the NIE Issued Date.')
                )
            # Create or update product.template
            product_tmpl = rec._create_or_link_product_template()
            rec.write({
                'state': 'nie_issued',
                'product_template_id': product_tmpl.id,
            })
            rec.message_post(
                body=_(
                    '🎉 NIE Issued! NIE Number: %s. Linked to product: %s'
                ) % (rec.nie_number, product_tmpl.name),
                message_type='notification',
                subtype_xmlid='mail.mt_comment',
            )
        return True

    def _create_or_link_product_template(self):
        """Create or link to product.template when NIE is issued."""
        self.ensure_one()
        ProductTemplate = self.env['product.template']
        # Check if a product with this NIE already exists
        existing = ProductTemplate.search(
            [('default_code', '=', self.nie_number)], limit=1
        )
        if existing:
            return existing
        # Create new product template
        vals = {
            'name': self.official_product_name or self.product_name,
            'default_code': self.nie_number,
            'type': 'consu',
            'description': _(
                'Auto-created from BPOM NIE Registration: %s\n'
                'NIE Number: %s\nIssued: %s'
            ) % (
                self.name,
                self.nie_number,
                self.nie_issued_date.strftime('%d %B %Y') if self.nie_issued_date else '',
            ),
        }
        return ProductTemplate.create(vals)

    # ────────────────────────────────────────────────────────────────────────
    # Button: Reset to Draft
    # ────────────────────────────────────────────────────────────────────────

    def action_reset_to_draft(self):
        """Reset to Draft (superuser / correction)."""
        for rec in self:
            rec.write({'state': 'draft'})
            rec.message_post(
                body=_('Record reset to Draft.'),
                message_type='notification',
            )
        return True
