/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState, onWillStart, onMounted } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

class ReportPlanPaymentDashboard extends Component {

    setup() {

        this.orm = useService("orm");

        this.state = useState({
            year: new Date().getFullYear(),
            month: new Date().getMonth() + 1,
            department_id: false,

            data: {},
            departments: [],
        });

        this.chartUsulanDana = null;
        this.chartAdvance = null;
        this.chartUpCountry = null;
        this.chartPettyCash = null;
        this.chartCancel = null;

        onWillStart(async () => {
            await this.loadDepartments();
            await this.loadDashboard();
        });

        onMounted(() => {
            this.renderCharts();
        });

    }

    async loadDepartments() {

        this.state.departments = await this.orm.searchRead(
            "hr.department",
            [],
            ["name"]
        );
    }

    async loadDashboard() {
        this.state.data = await this.orm.call(
            "usulan.report.plan.payment",
            "get_reporting_dashboard",
            [
                this.state.year,
                this.state.month,
                this.state.department_id,
            ]
        );
        setTimeout(() => {
            this.renderCharts();
        }, 100);
    }

    renderCharts() {
        this.renderUsulanDanaChart();
        this.renderAdvanceChart();
        this.renderUpCountryChart();
        this.renderPettyCashChart();
        this.renderCancelChart();
    }

    renderUsulanDanaChart() {
        const ctx = document.getElementById("chart_usulan_dana");
        if (!ctx) {
            return;
        }

        if (this.chartUsulanDana) {
            this.chartUsulanDana.destroy();
        }

        const chartData = this.state.data.chart?.usulan_dana || {};

        this.chartUsulanDana = new Chart(ctx, {
            type: "doughnut",
            data: {
                labels: [
                    "Planning",
                    "Paid"
                ],

                datasets: [{
                    data: [
                        chartData.plan || 0,
                        chartData.paid || 0,
                    ],
                }],
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "bottom",
                    },
                },
            },
        });
    }

    renderAdvanceChart() {

        const ctx = document.getElementById(
            "chart_advance"
        );

        if (!ctx) {
            return;
        }

        if (this.chartAdvance) {
            this.chartAdvance.destroy();
        }

        const chartData =
            this.state.data.chart?.advance || {};

        this.chartAdvance = new Chart(ctx, {

            type: "doughnut",

            data: {

                labels: [
                    "Rilis",
                    "Draft"
                ],

                datasets: [{
                    data: [
                        chartData.release || 0,
                        chartData.draft || 0,
                    ],
                }],
            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                plugins: {

                    legend: {
                        position: "bottom",
                    },
                },
            },
        });
    }

    renderUpCountryChart() {
        const ctx = document.getElementById("chart_upcountry");

        if (!ctx) {
            return;
        }

        if (this.chartUpCountry) {
            this.chartUpCountry.destroy();
        }

        const chartData = this.state.data.chart?.upcountry || {};

        this.chartUpCountry = new Chart(ctx, {
            type: "doughnut",
            data: {
                labels: [
                    "Rilis",
                    "Draft"
                ],

                datasets: [{
                    data: [
                        chartData.release || 0,
                        chartData.draft || 0,
                    ],
                }],
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "bottom",
                    },
                },
            },
        });
    }

    renderPettyCashChart() {
        const ctx = document.getElementById("chart_petty_cash");

        if (!ctx) {
            return;
        }

        if (this.chartPettyCash) {
            this.chartPettyCash.destroy();
        }

        const chartData = this.state.data.chart?.petty_cash || {};

        this.chartPettyCash = new Chart(ctx, {
            type: "doughnut",
            data: {
                labels: [
                    "Usulan",
                    "Payment"
                ],

                datasets: [{
                    data: [
                        chartData.usulan || 0,
                        chartData.payment || 0,
                    ],
                }],
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "bottom",
                    },
                },
            },
        });
    }

    renderCancelChart() {
        const ctx = document.getElementById("chart_cancel");

        if (!ctx) {
            return;
        }

        if (this.chartCancel) {
            this.chartCancel.destroy();
        }

        const chartData = this.state.data.chart?.cancel || {};

        this.chartCancel = new Chart(ctx, {
            type: "doughnut",
            data: {
                labels: [
                    "Cancel",
                    "Reschedule"
                ],

                datasets: [{
                    data: [
                        chartData.cancel || 0,
                        chartData.reschedule || 0,
                    ],
                }],
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "bottom",
                    },
                },
            },
        });
    }

    async selectMonth(month) {
        this.state.month = month;
        await this.loadDashboard();
    }

    async selectYear(ev) {
        this.state.year = parseInt(
            ev.target.value
        );
        await this.loadDashboard();
    }

    async selectDepartment(ev) {
        this.state.department_id =
            parseInt(ev.target.value) || false;
        await this.loadDashboard();
    }
}

ReportPlanPaymentDashboard.template =
    "custom_usulandana.ReportPlanPaymentDashboard";

registry.category("actions").add(
    "report_plan_payment_dashboard",
    ReportPlanPaymentDashboard
);