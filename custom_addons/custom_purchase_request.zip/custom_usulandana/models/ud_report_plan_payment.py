from odoo import models,fields,api
from datetime import date

class UsulanReportPlanPayment(models.Model):
    _name = 'usulan.report.plan.payment'
    _description = "Dashboard Reporting Plan Payment"

    def _has_attachment(self, record):
        return (
                hasattr(record, 'attachment_ids')
                and
                bool(record.attachment_ids)
        )

    @api.model
    def get_reporting_dashboard(
            self,
            year,
            month,
            department_id=False
    ):

        domain = []

        if department_id:
            domain.append(
                ('department_id', '=', int(department_id))
            )

        schedules = self.env[
            'usulan.payment.schedule'
        ].search(domain)

        # CHART DATA
        usulan_plan = len(
            schedules.filtered(
                lambda x:
                x.plan_payment_id.state == 'plan_payment'
            )
        )

        usulan_paid = len(
            schedules.filtered(
                lambda x:
                x.plan_payment_id.state == 'rilis'
            )
        )

        cancel_count = len(
            schedules.filtered(
                lambda x:
                x.plan_payment_id.state == 'cancel'
            )
        )

        reschedule_count = len(
            schedules.filtered(
                lambda x:
                x.plan_payment_id.state == 'reschedule'
            )
        )

        # TABLE DATA
        lines = []

        for s in schedules:
            usulan = (
                    s.plan_payment_id.usulan_dana_id
                    or
                    s.plan_payment_id.usulan_up_country_id
            )

            lines.append({
                'id': s.id,

                'tgl_usulan':
                    usulan.tgl_usulan
                    if hasattr(usulan, 'tgl_usulan')
                    else False,

                'no_usulan': usulan.name,
                'department': s.department_id.name,
                'description': s.plan_payment_id.description,
                'schedule_payment': s.plan_payment_date,
                'type':
                    'Usulan Dana'
                    if s.plan_payment_id.usulan_dana_id
                    else 'Up Country',
                'amount': s.amount,
                'status': s.plan_payment_id.state,
                'realization': s.actual_payment_date or '-',
                'attachment':
                    'Ada'
                    if self._has_attachment(usulan)
                    else '-',
            })

        return {
            'chart': {

                'usulan_dana': {
                    'plan': usulan_plan,
                    'paid': usulan_paid,
                },

                'advance': {
                    'release': 5,
                    'draft': 3,
                },

                'upcountry': {
                    'release': 7,
                    'draft': 2,
                },

                'petty_cash': {
                    'usulan': 4,
                    'payment': 1,
                },

                'cancel': {
                    'cancel': cancel_count,
                    'reschedule': reschedule_count,
                },
            },

            'lines': lines,
        }